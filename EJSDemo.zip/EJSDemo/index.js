
var express = require("express");

var app = express();

var mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/flipkart").then ( () => {
    console.log("connected to mongo db")
}).catch(
    (error) =>{
        console.log(error);
    }
)
var bodyParser = require('body-parser'); // middleware

var userRouter =  require('./routes/user.route');

app.set('view engine','ejs');

app.use(bodyParser.urlencoded({extended:true}));

app.use(userRouter);


app.get("/", (request,response) =>{
     response.render("index");
})

app.listen(9011, () =>{
    console.log("server started!");
})