var express = require("express");

var userRouter = express.Router();

userRouter.get("/register", (request,response) => {
    response.render("register");
})
userRouter.get("/login", (request,response) => {
    response.render("login");
})

userRouter.post("/register", (request,response) =>{
    console.log("registration in progress");
    console.log(request.body);
})

module.exports = userRouter;