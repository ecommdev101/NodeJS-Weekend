
const events = require("events");
const EventEmitter=new events.EventEmitter();

EventEmitter.once("init", () =>{
    console.log("App initialized");
})

EventEmitter.emit("init");
EventEmitter.emit("init");
EventEmitter.emit("init");
EventEmitter.emit("init");