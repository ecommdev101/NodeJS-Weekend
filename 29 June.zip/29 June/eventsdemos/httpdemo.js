const http = require('http');

var visitors = 0;

const server = http.createServer((req, res) => {
  res.end('Total Vistors today: '+ visitors);
});

server.on('request', () => {
  console.log('New request received!');
  visitors++;
});

server.listen(3000, () => {
  console.log('Server running on port 3000');
});
