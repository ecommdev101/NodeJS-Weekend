const events = require("events"); 

var EventEmitter = new events.EventEmitter();

EventEmitter.on("connect", function(input){
    console.log(input.username + " joined the chat");
})

EventEmitter.on("disconnect",function(input){
   console.log(input.username + " left the chat");
})

EventEmitter.emit("connect",{username: "kiran"});
EventEmitter.emit("disconnect",{username: "kiran"});

EventEmitter.emit("connect",{username: "naveen"});