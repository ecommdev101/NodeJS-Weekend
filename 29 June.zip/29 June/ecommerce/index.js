const http = require("http"); 

var server = http.createServer( function(request,response){

     if(request.url == "/"){

         response.end(`
            <html>

 <head>

     <style>
        a {
            text-decoration: none;
        }
     </style>

 </head>

  <body>

    <a href="http://localhost:4200/login">Login</a> &nbsp;&nbsp;
    <a href="http://localhost:4200/register">Register</a>&nbsp;&nbsp;
    <a href="http://localhost:4200/forgotpassword">Forgot Password</a>&nbsp;&nbsp;
    <a href="http://localhost:4200/products">Products</a>&nbsp;&nbsp;

  </body>

</html>
            `);

            return;

     }


     if(request.url == "/login"){

        response.end(`
            
            <html>

 <head>

     <style>
        a {
            text-decoration: none;
        }
     </style>

 </head>

  <body>

    <a href="http://localhost:4200/login">Login</a> &nbsp;&nbsp;
    <a href="http://localhost:4200/register">Register</a>&nbsp;&nbsp;
    <a href="http://localhost:4200/forgotpassword">Forgot Password</a>&nbsp;&nbsp;
    <a href="http://localhost:4200/products">Products</a>&nbsp;&nbsp;
 
    <br><br>
    <form>
         <input type="text" placeholder="email here"> <br><br>
         <input type="password" placeholder="password here"> <br><br>
         <button>Login</button>
    </form>

  </body>

</html>
            `)

            return;

     }

      if(request.url == "/register"){

        response.end(`
            
            <html>

 <head>

     <style>
        a {
            text-decoration: none;
        }
     </style>

 </head>

  <body>

    <a href="http://localhost:4200/login">Login</a> &nbsp;&nbsp;
    <a href="http://localhost:4200/register">Register</a>&nbsp;&nbsp;
    <a href="http://localhost:4200/forgotpassword">Forgot Password</a>&nbsp;&nbsp;
    <a href="http://localhost:4200/products">Products</a>&nbsp;&nbsp;
 
    <br><br>
    <form>
         <input type="text" placeholder="email here"> <br><br>
         <input type="password" placeholder="password here"> <br><br>
         <button>Register</button>
    </form>

  </body>

</html>
            `)

            return;

     }

});

server.listen(4200, function(){
    console.log("server started");
})


