const http = require("http"); 

const server = http.createServer(function(request, response){

    console.log(request.method);

    console.log("URL:",request.url);

    if(request.url ==  "/login"){

        response.end("<html> <body><form> <input type='text' placeholder='username'> <button>Login</button> </form> </body></html>");
        return;
    }

    if(request.url ==  "/register"){
       response.end("<html> <body><form> <input type='text' placeholder='username'> <button>Register</button> </form> </body></html>");
        return;
    }
     if(request.url ==  "/forgotpassword"){
       response.end("<html> <body><form> <input type='text' placeholder='email here'> <button>Send Email</button> </form></body></html>");
        return;
    }
    else{
            response.end("<h1>You are in home page</h1>");
    }

   
})

server.listen(9011, () =>{
    console.log("server started!!");
})

// http://localhost:9011/register

