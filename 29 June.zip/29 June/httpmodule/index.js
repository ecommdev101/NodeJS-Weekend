const http = require("http"); 

const server = http.createServer(function(request, response){

    console.log(request.method);

    response.end("<h1>This is from HTTP </h1>");
})

server.listen(9011, () =>{
    console.log("server started!!");
})

