const express = require("express");
var app = express(); // creates the server 
app.listen(9022, () =>{
    console.log("server started"); 
})

app.get("/user",function(request, response)
{
     response.send("<h1>I am from user route </h1>")
})

app.get("/product",function(request, response)
{
     response.send("<h1>I am from product route </h1>")
})
