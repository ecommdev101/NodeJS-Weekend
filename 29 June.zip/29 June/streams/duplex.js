
// duplex : readable + writeable

const fs = require("fs");

var reader = fs.createReadStream("10MB.txt",
    {
        highWaterMark: 64 * 1024
    }
);

var writer = fs.createWriteStream("10MBNEW.txt",
    {
        highWaterMark: 64 * 1024
    }
);

reader.pipe(writer);

reader.on("finish", () =>{
      console.log("reading finished");
})
writer.on("finish", () =>{
      console.log("writing finished");
})





