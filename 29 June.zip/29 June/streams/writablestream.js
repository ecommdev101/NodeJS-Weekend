const fs = require("fs");
const writer = fs.createWriteStream("chunks.txt");

writer.write("chunk 1");
writer.write("chunk 2");
writer.write("chunk 3");

writer.end();

writer.on("finish", () =>{
    console.log("writing finished")
})