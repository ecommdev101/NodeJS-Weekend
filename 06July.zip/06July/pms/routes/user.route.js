
 var express = require('express');

 let users = [];

 var  userRouter = express.Router();  // holds all the functions of Router();

userRouter.post("/register",(req,res) =>{
   var user =  req.body;
   users.push(user);
    res.send("user registered successfullly!");
})

userRouter.post("/forgotPassword",(req,res) =>{
   
    res.send("Reset Email is sent successfully!");
})

userRouter.post("/login", (req,res) =>{
    res.send("login called");
})

module.exports = userRouter; 

