var express =  require('express');

var ProductRouter = express.Router();

const products = [
     {
        productId: 101, 
        name: "Product 1",
        price: 4500, 
        stock: 10 
     },
      {
        productId: 102, 
        name: "Product 2",
        price: 8500, 
        stock: 2 
     }
];


ProductRouter.get("/all", (request, response) => {

   response.send(products);

} );



ProductRouter.post("/",(request, response) =>{
     
     products.push(request.body);

    response.send("Product added successfully!");
})

ProductRouter.delete("/:id",(request, response) =>{
         var isDeleted = false;
     
      products.forEach(
         (p,i) => 
         {
            if(p.productId == request.params.id)
            {
                isDeleted = true;
                  products.splice(i,1);
            }
})

      if(isDeleted){
  response.send("product deleted");
      }else{
 response.send("product not deleted");
      }
  
})

module.exports = ProductRouter;