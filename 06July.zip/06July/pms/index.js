
var express = require('express');

var app= express(); // ? app > holds all functions that are part of express()

app.use(express.json());
  
 var UserRouter = require("./routes/user.route");
 var ProductRouter = require("./routes/product.route");

app.get("/health", (req,res) =>{
    res.send("<h1>App is working! </h1>");
})



app.use("/user",UserRouter);
app.use("/product",ProductRouter);


app.listen(9090, () =>{
    console.log("server started!!");
})