// APPLICATION LEVEL MIDDLEWARE 

var express = require('express');

var app = express();

app.use(express.json()); // Built in middleware

var userRouter = require("./routes/user.route");
var productRouter = require("./routes/product.route");

// Middleware
const performAuthorization = (request,response,next) =>{

     if(request.headers.token  == undefined){
 response.send("<h1>Token in headers is not available</h1>");
 return;
     }
     if(request.headers.token == "intellipaat"){
         next(); // transfer the req,res to the actual API
     }
     else{
        response.send("<h1>Invalid token, please add the right token</h1>");
     }

}

// Application Level middleware
// app.use(performAuthorization);
app.use("/product",productRouter);
app.use("/user",userRouter);


app.get("/healthcheck", (req,res) =>{
     throw new Error("some error");
     res.send("<h1>App is working </h1>")
});

app.get("/support", (req,res) =>{
     
     res.send("<h1>Support Number is : 9090909090 </h1>")
});


const errorHandler = (err,req,res,next) => {
    console.log("error handler called");
       res.status(500).send('Something broke!');
}

app.use(errorHandler);

app.listen(9011, () =>{
    console.log("server started!");
})