var express = require("express");

var productRouter = express.Router(); 

const logDate = (req,res,next) =>{
    console.log("logDate middleware called");
    console.log("Date", new Date());
    next();
}
productRouter.use(logDate);
productRouter.get("/all",(request,response) =>{
    response.send(
         [
            {
                name:"product 1"
            },
             {
                name:"product 2"
            }
         ]
    )
})

productRouter.post("/add",(req,res) =>{
     console.log("request body:", req.body); 
})

module.exports = productRouter;