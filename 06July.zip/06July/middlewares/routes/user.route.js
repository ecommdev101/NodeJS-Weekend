var express = require("express");

var userRouter = express.Router(); 

const validateName = (req,res,next) =>{
    console.log("validateName middleware called");
     if(req.headers.name) {
        console.log("Name is:"+ req.headers.name);
         next();
     }
     else{
        res.send("<h1>Name shall be sent along with the request");
     }

}
userRouter.use(validateName); // Router Level Middleware
userRouter.get("/all",(request,response) =>{
    response.send(
         [
            {
                name:"kiran"
            },
             {
                name:"rajesh"
            }
         ]
    )
})



module.exports = userRouter;