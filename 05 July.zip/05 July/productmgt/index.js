
// CRUD APP - Product Management System C - Create,R- Retrieve,U- Update,D-Delete

var express = require('express');

const app = express();

app.use(express.json()); // middleware

const products = [
     {
        productId: 101, 
        name: "Product 1",
        price: 4500, 
        stock: 10 
     },
      {
        productId: 102, 
        name: "Product 2",
        price: 8500, 
        stock: 2 
     }
];

// API - List of Products, path = "/products"

// http://localhost:9090/products

app.get("/products", (request, response) => {

   response.send(products);

} );


// API - Add a new Product path = "/product"

// http://localhost:9090/products

app.post("/product",(request, response) =>{
     
     products.push(request.body);

    // response.send("Product added successfully!");
})

// app.delete("/product",(request, response) =>{
    

//          var isDeleted = false;
     
//       products.forEach(
//          (p,i) => 
//          {
//             if(p.productId == request.body.productId)
//             {
//                 isDeleted = true;
//                   products.splice(i,1);
//             }
// })

//       if(isDeleted){
//   response.send("product deleted");
//       }else{
//  response.send("product not deleted");
//       }
  
// })


app.delete("/product/:id",(request, response) =>{
         var isDeleted = false;
     
      products.forEach(
         (p,i) => 
         {
            if(p.productId == request.params.id)
            {
                isDeleted = true;
                  products.splice(i,1);
            }
})

      if(isDeleted){
  response.send("product deleted");
      }else{
 response.send("product not deleted");
      }
  
})

app.get("/healthcheck", (req,res) =>{

    res.setHeaders(new Headers({'Content-Type': 'text/html'}));

    res.send("<html><body><img src='https://www.shutterstock.com/image-vector/heart-pulse-graphic-vector-illustration-260nw-379870144.jpg'></body></html>")

})

app.get("/datainxml", (req,res) =>{

    res.setHeaders(new Headers({'Content-Type': 'application/xml'}));

    res.send("<root> <child1> </child1></root>")

})

app.listen(9090, () =>{
    console.log("server started!!");
})