var emailValidator = require("email-validator"); // third party module 

var email = "kiran@gmail"; 

 console.log(emailValidator.validate(email));


