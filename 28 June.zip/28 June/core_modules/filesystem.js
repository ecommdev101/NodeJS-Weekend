
// core modules - fs, http,https,url,querystring... 

const fs=require("fs");

var buffer = fs.readFileSync("creds.txt");

console.log(buffer.toString());






