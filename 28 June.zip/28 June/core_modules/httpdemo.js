var http= require("http");

var server = http.createServer(function(request,response){

    response.end("<h1> Welcome to Node.js! You are about to experience great learning!! </h1> <br> <img src='https://pbs.twimg.com/profile_images/1547577387596288003/daCjhjv1_400x400.jpg'>");

})

server.listen(9011, function(){
    console.log("server started!!");
});


// http://localhost:9011