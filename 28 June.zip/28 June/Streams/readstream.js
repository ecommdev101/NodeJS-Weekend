
const fs = require("fs"); 
const reader=fs.createReadStream("10MB.txt",
    {
        highWaterMark:  1024 * 1024 // chunk size -1 MB
    }
);

data = "";

reader.on("data",function(chunk){
    console.log(chunk);

})

reader.on("end", function(){
    console.log("streaming done.");
   // console.log(data);
})

reader.on("error", function(error){
    console.log(error);
})

