const calculator = require("./calculator");

calculator.add(10,20);

calculator.sub(20,10);
