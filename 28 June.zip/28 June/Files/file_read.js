//  const fs = require("fs"); 
//  console.log("1");
//   fs.readFile("package.json", function(error, data){
//  console.log("2");
//      if(data){
//         console.log(data.toString());
//      }

//      if(error){
//         console.log(error);
//      }
//   })
//   console.log("3");

// sync 

const fs = require("fs"); 
console.log("1");
const result=fs.readFileSync("package.json");
console.log("2");
console.log(result.toString()); 
console.log("3");

