const fs = require("fs"); 

fs.unlinkSync("new_users.txt");