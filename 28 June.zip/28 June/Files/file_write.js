
const fs = require("fs"); 

var users = "user 4, user 5 , user 6";

fs.writeFile("users.txt", users, (err) =>{

     if(err){
        console.log(err);
     }
     else{
        console.log("file written");
     }

});