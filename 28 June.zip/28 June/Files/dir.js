
const fs = require("fs"); 
console.log("1");
fs.rmdir("xyz", (err) =>{
    console.log("2");
    if(err){
        console.log(err);
    }
    else{
        console.log("directory removed");
    }
})
console.log("3");
