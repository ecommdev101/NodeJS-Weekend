const fs = require("fs"); 

fs.rmdirSync("../tempdir");

