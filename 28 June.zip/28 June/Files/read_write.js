const fs = require("fs"); 

var users =fs.readFileSync("users.txt");
fs.writeFileSync("new_users.txt",users.toString());