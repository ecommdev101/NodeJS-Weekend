
const fs = require("fs"); 

var users = " user 7, user 8 , user 9";

fs.appendFile("users.txt", users, (err) =>{

     if(err){
        console.log(err);
     }
     else{
        console.log("file written");
     }

});